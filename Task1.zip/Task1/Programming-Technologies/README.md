# Programming Technology Lab

## Team

| Name Surname (initials) | GUID                                     |
| ----------------------- | ---------------------------------------- |
| MS                      | `{3595FDBA-1EF2-4350-9D89-4ACE782B84CB}` |
| PW                      | `{9142D9FA-1E9B-4639-B65A-E99AC28FAC6F}` |
